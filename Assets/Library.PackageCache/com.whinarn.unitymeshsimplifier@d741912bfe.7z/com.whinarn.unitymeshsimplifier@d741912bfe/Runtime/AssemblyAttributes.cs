using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("Whinarn.UnityMeshSimplifier.Editor")]
